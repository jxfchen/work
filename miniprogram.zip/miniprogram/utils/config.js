const config = {
  api_base_url: "https://www.infinitybuild.cn/api.php/",
  image_base_url: "https://www.infinitybuild.cn"
}
export {
  config
}