const config = {
  api_base_url: "https://api.infinitybuild.cn/api.php/"
}
export { config }